//EJEMPLO SPA PLANTILLA
const app = new ProductoController(new ProductoModel(), new ProductoView());

const routes = [
	{ path: '/', action: 'agregar' },
	{ path: '/pagina1', action: 'listar' },
	{ path: '/pagina2', action: 'buscar' },
];

const parseLocation = () => location.hash.slice(1).toLowerCase() || '/';

const findActionByPath = (path, routes) => routes.find((r) => r.path === path || undefined);

const router = () => {
	const path = parseLocation();
	const action = findActionByPath(path, routes)?.action;
	console.log(action, path);
	switch (action) {
		case 'agregar':
			return app.agregar('#app');
		case 'listar':
			return app.listar('#app');
		case 'buscar':
			return app.buscar('#app');
		default:
			return ErrorComponent('#app');
	}
};

$(window).on('load', () => {
	router();
});

$(window).on('hashchange', () => {
	router();
});
